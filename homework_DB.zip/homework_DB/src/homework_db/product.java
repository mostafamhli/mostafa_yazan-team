package homework_db;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class product {

    private int id;
    private int price;
    private int amount;
    private String name;

    public product(int id, int price, int amount, String name) {
        this.id = id;
        this.price = price;
        this.amount = amount;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean insdb() throws SQLException {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(product.class.getName()).log(Level.SEVERE, null, ex);
        }
        Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/homework", "abc", "123");
        Statement s = con.createStatement();
        String a = "insert into product values(" + id + ",\'" + name + "\'," + price + "," + amount + ")";
        int i = s.executeUpdate(a);
        return (i==1);
    }

}
