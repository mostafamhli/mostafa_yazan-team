package homework_db;

import GUI.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Homework_DB {

    public static void main(String[] args) throws SQLException {
        
           new choose().setVisible(true);
            
    }

}
